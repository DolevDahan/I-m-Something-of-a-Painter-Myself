# unaligned_dataset_standalone.py
import os, random,torch, numpy as np
from PIL import Image
import torch.utils.data as data
import torchvision.transforms as T
from argparse import Namespace

# ─────────────────────────────────────────────────────────────
# 0)  כלי עזר בסיסיים
# ─────────────────────────────────────────────────────────────
_IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")
def is_image_file(name):
    return name.lower().endswith(_IMG_EXT)

def make_dataset(dir, max_dataset_size=float("inf")):
    images = []
    assert os.path.isdir(dir) or os.path.islink(dir), f"{dir} is not a valid directory"
    for root, _, fnames in sorted(os.walk(dir, followlinks=True)):
        for fname in fnames:
            if is_image_file(fname):
                images.append(os.path.join(root, fname))
    return images[: min(max_dataset_size, len(images))]

def copyconf(default_opt, **kwargs):
    conf = Namespace(**vars(default_opt))
    for k, v in kwargs.items():
        setattr(conf, k, v)
    return conf

# ─────────────────────────────────────────────────────────────
# 1)  טרנספורמציות – ללא crop
# ─────────────────────────────────────────────────────────────
def _make_power_2(img, base=4, method=Image.BICUBIC):
    ow, oh = img.size
    h, w = int(round(oh / base) * base), int(round(ow / base) * base)
    return img if (h == oh and w == ow) else img.resize((w, h), method)

def get_transform(opt, method=Image.BICUBIC):
    transforms = []

    if "resize" in opt.preprocess:
        size = [opt.load_size, opt.load_size]
        transforms.append(T.Resize(size, method))

    # לא נוסף crop בכלל
    transforms.append(T.Lambda(lambda img: _make_power_2(img, base=4, method=method)))

    if not opt.no_flip:
        transforms.append(T.RandomHorizontalFlip())

    transforms += [
        T.ToTensor(),
        T.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
    ]
    return T.Compose(transforms)

# ─────────────────────────────────────────────────────────────
# 2)  Dataset לא מזווג – ללא crop
# ─────────────────────────────────────────────────────────────
class UnalignedDataset(data.Dataset):
    def __init__(self, opt):
        self.opt           = opt
        self.root          = opt.dataroot
        self.current_epoch = 0

        phase_suffix = "" if opt.phase.endswith(("A", "B")) else opt.phase
        self.dir_A = os.path.join(opt.dataroot, f"{phase_suffix}A")
        self.dir_B = os.path.join(opt.dataroot, f"{phase_suffix}B")

        if opt.phase == "test" and not os.path.exists(self.dir_A) \
           and os.path.exists(os.path.join(opt.dataroot, "valA")):
            self.dir_A = os.path.join(opt.dataroot, "valA")
            self.dir_B = os.path.join(opt.dataroot, "valB")

        self.A_paths = sorted(make_dataset(self.dir_A, opt.max_dataset_size))
        self.B_paths = sorted(make_dataset(self.dir_B, opt.max_dataset_size))
        self.A_size  = len(self.A_paths)
        self.B_size  = len(self.B_paths)

        self.train_len = getattr(opt, "train_samples", None) if opt.phase == "train" else None

        self.base_transform = get_transform(opt)

    def __len__(self):
        if self.train_len is not None:
            return self.train_len
        return max(self.A_size, self.B_size)

    def __getitem__(self, index):
        A_path = self.A_paths[index % self.A_size]
        if self.opt.serial_batches:
            B_path = self.B_paths[index % self.B_size]
        else:
            B_path = self.B_paths[random.randint(0, self.B_size - 1)]

        A_img = Image.open(A_path).convert("RGB")
        B_img = Image.open(B_path).convert("RGB")

        transform = self.base_transform

        return {
            "A":       transform(A_img),
            "B":       transform(B_img),
            "A_paths": A_path,
            "B_paths": B_path,
        }



class SingleDataset(data.Dataset):
    """
    Dataset לטעינת תמונות מתיקייה אחת בלבד – שימושי לשלב inference / test,
    כאשר מפעילים גנרטור בכיוון אחד (A→B או B→A) ואין צורך בזיווג תמונות.
    """

    def __init__(self, opt):
        self.opt  = opt
        self.root = opt.dataroot                          # נתיב לתיקייה בודדת
        assert os.path.isdir(self.root) or os.path.islink(self.root), \
            f"{self.root} is not a valid directory"

        self.A_paths = sorted(make_dataset(self.root, opt.max_dataset_size))
        self.A_size  = len(self.A_paths)

        # קביעת טרנספורמציה בסיסית (RGB)
        self.transform = get_transform(opt)

        # במקרה של grayscale (input_nc == 1) – בונים טרנספורמציה מחדש
        input_nc = opt.output_nc if getattr(opt, "direction", "AtoB") == "BtoA" else opt.input_nc
        if input_nc == 1:
            base_tf = self.transform.transforms[:-2]        # כל מה שקודם ל-ToTensor+Normalize
            self.transform = T.Compose([
                *base_tf,
                T.Grayscale(num_output_channels=1),
                T.ToTensor(),
                T.Normalize((0.5,), (0.5,)),
            ])

    # מספר הדגימות ב-dataset
    def __len__(self):
        return self.A_size

    # קריאת תמונה ב-אינדקס *index* והחזרת מילון תואם לשאר הקוד
    def __getitem__(self, index):
        A_path = self.A_paths[index]
        A_img  = Image.open(A_path).convert("RGB")
        A      = self.transform(A_img)

        # טנזור placeholder עם אותם ממדים (0-ים); אפשר גם A.clone() אם מעדיפים
        B = torch.zeros_like(A)

        return {
            "A": A, "B": B,               # שני המפתחות שה-model דורש
            "A_paths": A_path,
            "B_paths": A_path,            # מצביע לאותה תמונה (לא קריטי בשלב test)
        }
# ─────────────────────────────────────────────────────────────
# 3)  SimpleDataLoader – ללא שינוי
# ─────────────────────────────────────────────────────────────
class SimpleDataLoader:
    def __init__(self, dataloader, dataset, opt):
        self.dataloader = dataloader
        self.dataset    = dataset
        self.opt        = opt

    def __len__(self):
        return min(len(self.dataset), self.opt.max_dataset_size)

    def __iter__(self):
        for i, data in enumerate(self.dataloader):
            if i * self.opt.batch_size >= self.opt.max_dataset_size:
                break
            yield data

    def set_epoch(self, epoch):
        self.dataset.current_epoch = epoch

# # unaligned_dataset_standalone.py
# import os, random, numpy as np
# from PIL import Image
# import torch.utils.data as data
# import torchvision.transforms as T
# from argparse import Namespace

# # ─────────────────────────────────────────────────────────────
# # 0)  כלי עזר בסיסיים
# # ─────────────────────────────────────────────────────────────
# _IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")
# def is_image_file(name):               # בדיקת סיומת-קובץ
#     return name.lower().endswith(_IMG_EXT)

# def make_dataset(dir, max_dataset_size=float("inf")):
#     """אסף את כל קבצי-התמונה מתיקייה (רק נתיבים)"""
#     images = []
#     assert os.path.isdir(dir) or os.path.islink(dir), f"{dir} is not a valid directory"
#     for root, _, fnames in sorted(os.walk(dir, followlinks=True)):
#         for fname in fnames:
#             if is_image_file(fname):
#                 images.append(os.path.join(root, fname))
#     return images[: min(max_dataset_size, len(images))]

# def copyconf(default_opt, **kwargs):
#     """שכפול אובייקט ‎opt‎ עם override לשדות ספציפיים"""
#     conf = Namespace(**vars(default_opt))
#     for k, v in kwargs.items():
#         setattr(conf, k, v)
#     return conf

# # ─────────────────────────────────────────────────────────────
# # 1)  טרנספורמציות (הועתקו מ-BaseDataset, בגרסה מצומצמת)
# # ─────────────────────────────────────────────────────────────
# def _scale_width(img, target_w, crop_w, method=Image.BICUBIC):
#     ow, oh = img.size
#     if ow == target_w and oh >= crop_w:
#         return img
#     h = int(max(target_w * oh / ow, crop_w))
#     return img.resize((target_w, h), method)

# def _make_power_2(img, base=4, method=Image.BICUBIC):
#     ow, oh = img.size
#     h, w = int(round(oh / base) * base), int(round(ow / base) * base)
#     return img if (h == oh and w == ow) else img.resize((w, h), method)

# def get_transform(opt, method=Image.BICUBIC):
#     """רק מה שנדרש ל-CUT/FastCUT – resize→crop→flip→Tensor→Normalize"""
#     transforms = []
#     # resize
#     if "resize" in opt.preprocess:
#         size = [opt.load_size, opt.load_size]
#         transforms.append(T.Resize(size, method))
#     elif "scale_width" in opt.preprocess:
#         transforms.append(T.Lambda(lambda img: _scale_width(img, opt.load_size,
#                                                             opt.crop_size, method)))
#     # crop
#     if "crop" in opt.preprocess:
#         transforms.append(T.RandomCrop(opt.crop_size))
#     # adjust to power-of-2
#     transforms.append(T.Lambda(lambda img: _make_power_2(img, base=4, method=method)))
#     # flip
#     if not opt.no_flip:
#         transforms.append(T.RandomHorizontalFlip())
#     # to tensor & normalization
#     transforms += [T.ToTensor(),
#                    T.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]
#     return T.Compose(transforms)


# class UnalignedDataset(data.Dataset):
#     """
#     טעינת דאטה-סט לא מזווג (unaligned) לשימוש ב-CycleGAN/CUT.
#     תומך בפרמטר opt.train_samples כדי לשלוט בגודל קבוצת האימון.
#     """

#     def __init__(self, opt):
#         self.opt           = opt
#         self.root          = opt.dataroot
#         self.current_epoch = 0

#         phase_suffix = "" if opt.phase.endswith(("A", "B")) else opt.phase
#         self.dir_A = os.path.join(opt.dataroot, f"{phase_suffix}A")
#         self.dir_B = os.path.join(opt.dataroot, f"{phase_suffix}B")

#         if opt.phase == "test" and not os.path.exists(self.dir_A) \
#            and os.path.exists(os.path.join(opt.dataroot, "valA")):
#             self.dir_A = os.path.join(opt.dataroot, "valA")
#             self.dir_B = os.path.join(opt.dataroot, "valB")

#         self.A_paths = sorted(make_dataset(self.dir_A, opt.max_dataset_size))
#         self.B_paths = sorted(make_dataset(self.dir_B, opt.max_dataset_size))
#         self.A_size  = len(self.A_paths)
#         self.B_size  = len(self.B_paths)

#         # תמיכה ב-train_samples
#         self.train_len = getattr(opt, "train_samples", None) if opt.phase == "train" else None

#         self.base_transform = get_transform(opt)

#     def __len__(self):
#         if self.train_len is not None:
#             return self.train_len
#         return max(self.A_size, self.B_size)

#     def __getitem__(self, index):
#         if self.train_len is not None:
#             A_path = self.A_paths[index % self.A_size]
#             if self.opt.serial_batches:
#                 B_path = self.B_paths[index % self.B_size]
#             else:
#                 B_path = self.B_paths[random.randint(0, self.B_size - 1)]
#         else:
#             A_path = self.A_paths[index % self.A_size]
#             if self.opt.serial_batches:
#                 index_B = index % self.B_size
#             else:
#                 index_B = random.randint(0, self.B_size - 1)
#             B_path = self.B_paths[index_B]

#         A_img = Image.open(A_path).convert("RGB")
#         B_img = Image.open(B_path).convert("RGB")

#         is_finetune = getattr(self.opt, "isTrain", False) and \
#                       (self.current_epoch > self.opt.n_epochs)

#         if is_finetune:
#             local_opt = copyconf(self.opt, load_size=self.opt.crop_size)
#             transform = get_transform(local_opt)
#         else:
#             transform = self.base_transform

#         return {
#             "A":       transform(A_img),
#             "B":       transform(B_img),
#             "A_paths": A_path,
#             "B_paths": B_path,
#         }

# class SimpleDataLoader:
#     def __init__(self, dataloader, dataset, opt):
#         self.dataloader = dataloader
#         self.dataset    = dataset
#         self.opt        = opt

#     # מאפשר len(dataset)
#     def __len__(self):
#         return min(len(self.dataset), self.opt.max_dataset_size)

#     # מאפשר for batch in dataset:
#     def __iter__(self):
#         for i, data in enumerate(self.dataloader):
#             if i * self.opt.batch_size >= self.opt.max_dataset_size:
#                 break
#             yield data

#     # אופציונלית – כמו במקור:
#     def set_epoch(self, epoch):
#         self.dataset.current_epoch = epoch